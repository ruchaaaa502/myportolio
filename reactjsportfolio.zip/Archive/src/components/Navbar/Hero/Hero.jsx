import React from "react";

import styles from "./Hero.module.css";
import { getImageUrl } from "../../../utils.js";

export const Hero = () => {
  return (
    <section className={styles.container}>
      <div className={styles.content}>
        <h1 className={styles.title}>Hi, I'm Rucha</h1>
        <p className={styles.description}>
          I'm a student who is eager to learn Full-Stack Development and this is 
          First Rectjs project!
        </p>
        <a href="mailto:nakilrucha09@email.com" className={styles.contactBtn} >
          Contact Me
        </a>
      </div>
      <img
        src="https://static.vecteezy.com/system/resources/previews/002/309/577/non_2x/business-woman-manager-in-office-concept-young-happy-smiling-businesswoman-clerk-cartoon-character-sitting-at-work-table-with-coffee-and-laptop-vector.jpg"
        alt="Hero image of me"
        
        className={styles.heroImg}
      />
      
    </section>
  );
};
